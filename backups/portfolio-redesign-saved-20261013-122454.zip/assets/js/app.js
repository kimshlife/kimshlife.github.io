/* ===== 네비 · 라우팅 ===== */
const NAV=[
 {id:'home',label:'Home',k:'build'},
 {id:'about',label:'About',k:'idea'},
 {id:'works',label:'Works',k:'work'},
 {id:'hobby',label:'Hobby',k:'game'},
 {id:'contact',label:'Contact',k:'mail'}
];
const $=s=>document.getElementById(s);
function buildNav(el){el.innerHTML=NAV.map(n=>
 `<a class="navlink" href="#/${n.id==='home'?'':n.id}" data-nav="${n.id}">${ico(n.k,18)}<span>${n.label}</span></a>`).join('')}
['nav-rail','nav-top','nav-tab'].forEach(i=>buildNav($(i)));
function syncNav(a){document.querySelectorAll('[data-nav]').forEach(x=>
 x.dataset.nav===a?x.setAttribute('aria-current','page'):x.removeAttribute('aria-current'))}

let state={view:'select',cat:'all',slug:null,tab:'skill',hsec:'',htab:'overview',hdoc:'',gfilter:''};
/* 예전 기획 첫 화면 주소(#/planning, #/game 등 지원 분야별 주소)는 기획 사례로 보냅니다 */
const OLD_PLANNING=['planning','hr','game','service','biz'];
function route(){
  const wasAbout=state.view==='about';
  const parts=(location.hash||'#/').slice(2).split('/').filter(Boolean);
  state.slug=null;
  if(!parts.length){state.view='select';}                       // 첫 화면 — 표지(직군 선택)
  else if(OLD_PLANNING.indexOf(parts[0])>=0){location.replace('planning/');return;}
  else if(parts[0]==='works'){
    if(parts[1]==='bodybuilder'&&parts[2]==='workshop')state.view='workshop';
    else if(parts[1]){state.view='detail';state.slug=parts[1];}
    else state.view='works';
  } else if(parts[0]==='about'){state.view='about';state.tab=parts[1]||'skill';}
  else if(parts[0]==='hobby'){state.view='hobby';state.hsec=parts[1]||'';state.htab=parts[2]||'overview';state.hdoc=parts[3]||'';}
  else if(parts[0]==='contact')state.view='contact';
  else state.view='404';
  render();
  if(wasAbout&&state.view==='about'){
    const panel=$('about-panel');panel.focus({preventScroll:true});panel.scrollIntoView({block:'start'});
  }else window.scrollTo(0,0);
}
window.addEventListener('hashchange',route);

/* ===== 공통 ===== */
const IMG='assets/img/';
/* 이력서 — 공개할 준비가 되면 주소를 넣으세요. 비워 두면 '준비 중'으로 표시됩니다.
   예: RESUME='https://drive.google.com/file/d/....../view' */
const RESUME='';
function catDot(k){const c=CAT[k];return `<span class="cd"><i style="background:${c.c}"></i>${c.n}</span>`}
function tbl(head,rows,cls){return `<div class="scroll"><table class="tbl">
  <thead><tr>${head.map(h=>`<th scope="col"${h[1]?` style="width:${h[1]}"`:''}>${h[0]}</th>`).join('')}</tr></thead>
  <tbody>${rows.map(r=>`<tr>${r.map((c,i)=>`<td data-label="${head[i][0]}" class="${(cls&&cls[i])||''}"><div>${c}</div></td>`).join('')}</tr>`).join('')}</tbody>
</table></div>`}
/* lv=1 이면 h1 으로 그립니다. 화면마다 h1 이 하나씩은 있어야 스크린리더가 제목을 읽습니다 */
function sechead(icon,title,right,lv){const t=lv===1?'h1':'h2';
  return `<div class="sechead">${ico(icon,20)}<${t} class="d2">${title}</${t}>
  ${right?`<span class="cap">${right}</span>`:''}</div>`}

/* ===== SELECT — 첫 화면, 직군 선택 =====
   내용은 data.js 의 SELECT 에서 고칩니다. 왼쪽 메뉴 없이 카탈로그 한 장으로 그립니다. */
function selectCard(m){
  if(m.soon)return `<div class="model soon" aria-label="준비 중인 직군">
    <div class="model-top"><span>MODEL ${m.no}</span><span>SOON</span></div>
    <div class="soon-body">TO BE<br>CONTINUED…</div></div>`;
  return `<a class="model" href="${m.href}">
    <div class="model-top"><span>MODEL ${m.no}</span><span>KSH-${m.code}</span></div>
    <div class="model-ico">${ico(m.icon,40)}</div>
    <h2 class="model-name">${m.name}</h2>
    <div class="model-en">${m.en}</div>
    <figure class="model-fig"><img src="${m.img}" alt="${m.alt||''}" loading="lazy"></figure>
    <dl class="model-spec">${m.spec.map(([k,v])=>`<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>
    <span class="model-go">설명서 열기 →</span></a>`;
}
function viewSelect(){return `<section class="home-intro"><div><span class="eyebrow">KIM SI HOO / PORTFOLIO</span><h1 class="d1">생각을 규칙으로,<br>경험을 더 나은<br>플레이로.</h1><p class="home-position">김시후 · 게임·서비스 기획 / 게임 분석·QA</p><p>요구사항과 규칙을 설계하고, 실제 플레이에서 발견한 문제를 재현 조건과 검증 근거로 남깁니다.</p><div class="home-actions"><a class="abtn primary" href="#/works">프로젝트 살펴보기 ↗</a><a class="abtn" href="mailto:kimshlife@naver.com">이메일로 연락하기</a></div></div><figure><img src="assets/img/ss-title.jpg" alt="SSketch — 위대한 그림 도둑" fetchpriority="high"><figcaption>${ico('trophy',17)} SSketch · SSAFY 15기 특화 프로젝트 우수상</figcaption></figure></section>
<section class="role-paths" aria-label="직군별 포트폴리오"><a class="role-path" href="planning/"><span class="eyebrow">PLANNING</span><h2>기획</h2><p>규칙·수치·요구사항을 결정하고<br>실행 가능한 명세로 연결한 작업.</p><span class="go">기획 사례 4개 보기 →</span></a><a class="role-path" href="qa/"><span class="eyebrow">GAME ANALYSIS / QA</span><h2>게임 분석·QA</h2><p>이용자의 문제를 관찰하고<br>재현·원인 분석·검증으로 이어간 작업.</p><span class="go">분석·검증 사례 4개 보기 →</span></a></section>
<section class="home-section"><div class="section-line"><div><span class="eyebrow">SELECTED PROJECTS</span><h2>대표 프로젝트</h2></div><a href="#/works">전체 7개 프로젝트 →</a></div><div class="cards">${['ssketch','bodybuilder','sickkick','contentops'].map(cardHTML).join('')}</div></section>
<section class="home-section home-about"><div><span class="eyebrow">ABOUT ME</span><h2>제약을 이해하고,<br>함께 실행할 기준을 만듭니다.</h2><a href="#/about">소개와 역량 보기 →</a></div><dl>${SELECT.sheet.map(([k,v,d])=>`<div><dt>${k}</dt><dd>${v}${d?`<small>${d}</small>`:''}</dd></div>`).join('')}</dl></section>
<section class="home-section"><div class="section-line"><h2>오래 플레이하며 남긴 기록</h2><a href="#/hobby">플레이 기록 →</a></div><p class="work-intro">${GAMES.length}개 게임의 플레이 기록, 6년간의 길드 운영, 한 게임을 오래 관찰한 분석 문서를 모았습니다.</p></section>`}

const PROJECT_AWARDS={ssketch:'SSAFY 특화 프로젝트 우수상',sickkick:'교내 대상 · K7U-Belt 장려상',contentops:'대한민국 신직업 공모전 장려상'};
function awardBadge(k){return PROJECT_AWARDS[k]?`<span class="award-badge">${ico('trophy',17)}<span>${PROJECT_AWARDS[k]}</span></span>`:'';}
const CARD_ROLES={
  ssketch:'요구사항 명세·진척 관리 · 설정 창 기획·구현 · 게임 규칙 코드',
  bodybuilder:'UGC 정책·명세 설계 · 캐릭터 상태 설계 · 프론트엔드',
  neontetris:'게임 규칙 표준화 · 락 딜레이·회전 제한 설계',
  projectrg:'5축 진단 체계 · 보충 질문 규칙 · 프론트엔드',
  sickkick:'시장·규제 분석 · 수익 구조 · 사업 전략',
  contentops:'팀 운영 · 산업 분석 · 자격·기업 인증제 설계',
  pirukia:'9신 세계관 구조 · 교리 선택지 콘텐츠 설계'
};

/* ===== WORKS ===== */
function cardMedia(p){
  if(p.thumb)return `<img class="cardthumb" src="${IMG}${p.thumb}" alt="" loading="lazy">`;
  /* 이미지가 아직 없는 프로젝트 — 문서 규격을 그대로 자리표시자로 씁니다 */
  return `<div class="cardph"><span class="phid">${p.docId}</span><span class="phv">${p.ver}</span></div>`;
}
/* 어느 직군 설명서에 실렸는지 — data.js 의 MANUAL_TAGS */
function manualBadges(k){const t=(typeof MANUAL_TAGS!=='undefined'&&MANUAL_TAGS[k])||[];
  return t.length?`<span class="mbadges">${t.map(([n])=>`<span class="mbadge">${n} 사례</span>`).join('')}</span>`:''}
function manualLinks(k){const t=(typeof MANUAL_TAGS!=='undefined'&&MANUAL_TAGS[k])||[];
  return t.length?`<p class="manual-links"><span>직군별 사례</span>${t.map(([n,h])=>`<a href="${h}">${n==='QA'?'게임 분석·QA':'기획'} →</a>`).join('')}</p>`:''}
function cardHTML(k){const p=P[k];return `<a class="card" href="#/works/${p.slug}">
  <div class="card-media">${cardMedia(p)}${awardBadge(k)}</div>
  <div class="cardbody">
    <div class="top">${p.cats.map(catDot).join('')}${manualBadges(k)}</div>
    <h3 class="ttl">${p.title}</h3>
    <div class="what">${p.what}</div>
    <div class="rolebox"><span class="eyebrow" style="margin-bottom:6px">핵심 기여</span><div class="txt">${CARD_ROLES[k]||p.role}</div></div>
    <div class="when">${p.period}<span class="card-go">프로젝트 보기 ↗</span></div>
  </div></a>`}
/* 분류는 한 번에 하나만 고릅니다(라디오). 고른 칩만 Tab 으로 들어오고, 그룹 안에서는 화살표로 옮깁니다 */
function radioChip(k,label){const on=state.cat===k;
  return `<button type="button" class="chip" role="radio" aria-checked="${on}" tabindex="${on?0:-1}" data-cat="${k}">${label}</button>`}
function viewWorks(){
  const c=state.cat,list=c==='all'?ORDER:c==='awarded'?ORDER.filter(k=>PROJECT_AWARDS[k]):ORDER.filter(k=>P[k].cats.includes(c));
  const cnt=k=>ORDER.filter(s=>P[s].cats.includes(k)).length;
  return `<section>
    <span class="eyebrow">PROJECT ARCHIVE</span>${sechead('work','프로젝트',`${list.length}개 프로젝트`,1)}<p class="work-intro">게임부터 서비스·사업·콘텐츠까지. 각 프로젝트에서 맡은 역할과 판단의 근거를 정리했습니다.</p>
    <div class="filters" role="radiogroup" aria-label="분류">
      ${radioChip('all',`전체 <span class="n">${ORDER.length}</span>`)}${radioChip('awarded',`${ico('trophy',15)} 수상 프로젝트 <span class="n">${Object.keys(PROJECT_AWARDS).length}</span>`)}
      ${Object.keys(CAT).map(k=>radioChip(k,`<i style="background:${CAT[k].c}"></i>${CAT[k].n} <span class="n">${cnt(k)}</span>`)).join('')}
    </div>
    ${list.length?`<div class="cards">${list.map(cardHTML).join('')}</div>`
      :`<div class="empty"><p class="cap" style="margin-bottom:18px">선택한 조건에 맞는 프로젝트가 없습니다.</p>
        <button type="button" class="abtn" data-cat="all">필터 초기화</button></div>`}
  </section>`;
}

/* ===== 상세 ===== */
function docspec(p){return `<div class="docspec">
  <div class="meta">${p.period} · ${p.team}</div>
  <h1 class="d2">${p.title}</h1>
  <p class="body-l project-intro">${p.what}</p>
  <div style="display:flex;gap:12px;margin-top:10px;flex-wrap:wrap">${p.cats.map(catDot).join('')}</div>
  <p class="project-role">${p.role}</p>
  <details class="project-spec"><summary>담당 범위와 프로젝트 정보</summary><dl>
    <dt class="eyebrow">기획 원안</dt><dd class="dim">${p.originator}</dd>
    <dt class="eyebrow">담당 범위</dt><dd><ul>${p.scope.map(s=>`<li>${s}</li>`).join('')}</ul></dd>
    <dt class="eyebrow">팀 구성</dt><dd class="dim">${p.team}</dd>
    <dt class="eyebrow">기술 환경</dt><dd class="dim">${p.stack}</dd>
    <dt class="eyebrow">산출물</dt><dd class="dim">${p.outputs}</dd>
  </dl><p class="cap spec-id">${p.docId} · ${p.ver}</p></details></div>`}
function blk(no,icon,t,inner){return `<div class="block" id="section-${no==='◆'?'overview':no}"><div class="blockhead">
  <span class="no">${no}</span>${ico(icon,18)}<h2 class="h3">${t}</h2></div>${inner}</div>`}
function gallery(p){
  if(!p.gallery||!p.gallery.length)return '';
  const st=p.galRatio?` style="aspect-ratio:${p.galRatio}"`:'';
  return `<div class="gal">${p.gallery.map(g=>
    `<figure><button type="button" class="gallery-open" aria-label="이미지 확대: ${g.c}"><img src="${IMG}${g.f}.${g.e||'jpg'}" alt="${g.c}" loading="lazy"${st}><span aria-hidden="true">확대 ↗</span></button><figcaption>${g.c}</figcaption></figure>`).join('')}</div>`;
}
const YT_ALLOW='accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;web-share';
function ytEmbeddable(){return location.protocol==='http:'||location.protocol==='https:'}
function ytFrame(id){return `<iframe class="frame" src="https://www.youtube.com/embed/${id}?autoplay=1&amp;rel=0&amp;playsinline=1"
    title="시연 영상" referrerpolicy="strict-origin-when-cross-origin"
    allow="${YT_ALLOW}" allowfullscreen></iframe>`}
function videoSlot(p){
  if(p.video===undefined)return '';
  if(!p.video)return `<div class="vid"><div class="vidph">${ico('play',26)}<span class="cap">시연 영상 준비 중</span></div></div>`;
  const id=p.video, watch=`https://www.youtube.com/watch?v=${id}`;
  /* 썸네일 파사드 — 클릭할 때만 iframe을 삽입한다.
     file:// 로 열면 유튜브가 Referer를 받지 못해 오류 153이 나므로, 그때는 새 탭 링크로 대체한다. */
  const face=`<img class="vidthumb" src="https://i.ytimg.com/vi/${id}/maxresdefault.jpg" alt="" decoding="async"
      onerror="this.onerror=null;this.src='https://i.ytimg.com/vi/${id}/hqdefault.jpg'"><span class="pbtn">${ico('play',30)}</span>`;
  const facade = ytEmbeddable()
    ? `<button class="vidfacade" type="button" data-yt="${id}" aria-label="시연 영상 재생">${face}</button>`
    : `<a class="vidfacade" href="${watch}" target="_blank" rel="noopener" aria-label="유튜브에서 시연 영상 보기">${face}
        <span class="vnote">로컬 파일(file://)에서는 유튜브 재생이 차단됩니다 · 클릭하면 유튜브에서 열립니다</span></a>`;
  return `<div class="vid">${facade}</div>
    <p class="cap" style="margin-top:8px"><a href="${watch}" target="_blank" rel="noopener">유튜브에서 보기 →</a></p>`;
}
/* 링크가 없는 산출물은 <a> 로 만들지 않습니다. href="#" 이면 눌렀을 때 첫 화면으로 튕깁니다 */
function artifactBtn(l){
  const inner=`${ico(l.href&&l.href.startsWith('#')?'doc':'link',16)}${l.t} <span class="m">${l.m}</span>`;
  if(l.off||!l.href)return `<span class="abtn" aria-disabled="true">${inner}</span>`;
  const ext=!l.href.startsWith('#');
  return `<a class="abtn" href="${l.href}"${ext?' target="_blank" rel="noopener"':''}>${inner}</a>`;
}
function viewDetail(){
  const p=P[state.slug];if(!p)return view404();
  const ord=ORDER,i=ord.indexOf(state.slug),pv=ord[(i-1+ord.length)%ord.length],nx=ord[(i+1)%ord.length];
  return `<a class="crumb" href="#/works">${ico('work',15)} Works</a>
  ${docspec(p)}${PROJECT_AWARDS[state.slug]?`<div class="award-detail">${awardBadge(state.slug)} <a href="#/about/award">수상 내역 →</a></div>`:''}
  ${p.thumb?`<figure class="project-cover"><img src="${IMG}${p.thumb}" alt="${p.title} 대표 화면" fetchpriority="high"></figure>`:''}
  <div class="project-actions">${p.links.map(artifactBtn).join('')}</div>
  ${manualLinks(state.slug)}
  <section class="project-highlights" aria-label="주요 수치와 근거"><h2 class="h3">주요 수치와 근거</h2><div class="metrics">${p.metrics.map(m=>
    `<div class="metric"><div class="val">${m.v}</div><div class="lb">${m.l}</div><div class="src">${m.s}</div></div>`).join('')}</div></section>
  <nav class="project-toc" aria-label="프로젝트 목차"><a href="#section-01" data-scroll="section-01">문제 정의</a><a href="#section-02" data-scroll="section-02">역할과 판단</a><a href="#section-03" data-scroll="section-03">산출물</a><a href="#section-04" data-scroll="section-04">회고</a></nav>${blk('01','problem','문제 정의',p.problem.map(t=>`<p style="color:var(--ink-2)">${t}</p>`).join(''))}
  ${blk('02','decide','역할과 의사결정',p.decisions.map(d=>`<div class="dec">
    <div class="h">${ico('spec',16)}<span>${d.h}</span></div><div class="b">${d.b}</div>
    ${d.link?`<p class="cap" style="margin:9px 0 0 25px"><a href="${d.link}">${d.linkT} →</a></p>`:''}</div>`).join(''))}
  ${p.notes.map(n=>`<div class="note inline-note"><b>${n.t}</b>${n.b}</div>`).join('')}
  ${blk('03','doc','산출물',`<p class="cap">${p.outputs}</p>${gallery(p)}${videoSlot(p)}`)}
  ${blk('04','result','회고',`<p style="color:var(--ink-2)">${p.retro}</p>`)}
  <div class="pager"><a href="#/works/${pv}">← ${P[pv].title}</a><a href="#/works/${nx}">${P[nx].title} →</a></div>`;
}

/* ===== 창작마당 심화 ===== */
function viewWorkshop(){const p=P.bodybuilder;return `<a class="crumb" href="#/works/bodybuilder">${ico('work',15)} BodyBuilder</a>
<div class="docspec">
  <div class="meta">BodyBuilder / 창작마당 기능 · 명세서 v9 · 2026.08</div>
  <h1 class="d2">창작마당 — 유저 맵 제작·공유 시스템</h1>
  <dl>
    <dt class="eyebrow">담당</dt><dd>구현명세서(v1–v9), 프론트·백엔드 작업지시서 작성 · 정책 설계 · 프론트엔드 구현</dd>
    <dt class="eyebrow">수행 구조</dt><dd class="dim">백엔드는 작성한 지시서에 따라 다른 팀원이 수행</dd>
    <dt class="eyebrow">범위</dt><dd class="dim">Phase 1 (좋아요·평점·댓글은 Phase 2로 분리)</dd>
  </dl></div>

${blk('◆','doc','문서를 다루는 방식',tbl([['항목','130px'],['내용','']],[
 ['전제 재검증','기준 커밋이 바뀌자 명세가 딛고 선 5개 전제를 전부 다시 확인하고 판정을 남겼습니다. 그 과정에서 시뮬레이션 입력 시그니처가 바뀐 것을 발견해 기록했습니다.'],
 ['범위 산정','프로토타입을 전부 반영하면 테이블 3개와 API 6개, 인증 로직이 추가되어 범위가 두 배 이상이 된다고 산정했습니다. 핵심 가치는 맵을 만들어 함께 노는 것이고 소셜 기능은 그 위에 얹는 층이라고 판단해 Phase 2로 잘랐습니다.'],
 ['변경 파급 추적','창작마당을 로비 탭에서 헤더 최상위로 옮기는 변경이, 방 생성 요청에 스테이지 값이 필요해지는 API 계약 변경까지 이어진다는 것을 짚었습니다.']
],['st','q']))}

${blk('01','problem','기능 정의',
`<p style="color:var(--ink-2)">공식 맵만으로는 콘텐츠가 곧 소진됩니다. 유저가 직접 맵을 만들어 공유하면 플레이할 거리가 계속 생기지만, 동시에 두 가지 위험이 따라옵니다. 깰 수 없는 맵이 공개되어 다른 사람의 시간을 버리는 것, 그리고 부가 기능의 문제가 본 게임을 막는 것입니다.</p>
<p style="color:var(--ink-2)">따라서 이 기능의 설계 목표는 창작 자유도가 아니라 <mark>품질 보증과 격리</mark>였습니다.</p>
<div class="gal" style="margin-top:20px">
<figure><img src="${IMG}ws-list.jpg" alt="창작마당 목록 화면" loading="lazy"><figcaption>공개 맵 탐색 — 팔레트 그라디언트 썸네일, 난이도 뱃지, 우하단에 폴리곤·기믹 수</figcaption></figure>
<figure><img src="${IMG}ws-newmap.jpg" alt="새 맵 만들기 모달" loading="lazy"><figcaption>새 맵 만들기 — 제목만 받고, 검증 기준을 미리 안내합니다</figcaption></figure>
</div>`)}

${blk('02','decide','설계 결정과 근거',tbl([['결정','32%'],['근거','']],[
 ['상한을 실측에서 도출<br><span class="data" style="color:var(--accent)">폴리곤 ≤8 · 정점 ≤20 · 기믹 ≤5</span>','공식 맵 6개의 실제 값은 폴리곤 2–3개, 정점 4–6개, 기믹 0–2개였습니다. 감으로 정하지 않고 실측치에 여유를 더해 상한을 잡았습니다.'],
 ['초기안 폐기','시뮬레이션 벽시계 타임아웃은 물리 엔진의 결정성 계약을 깨뜨려 같은 입력이 같은 결과를 내지 못하게 합니다. 리플레이 재현성이 무너지므로 버렸습니다.'],
 ['예약 ID 대역 채택','커스텀 맵을 별도 도메인으로 분리하는 안과 비교했을 때, 분리 쪽이 공식 게임 경로의 회귀 위험이 더 컸습니다.'],
 ['완료 기준을 원칙으로 정의','공식 게임의 동작을 바꾸지 않는다, 그 증거는 기존 테스트가 무수정으로 통과하는 것이다. 검증 가능한 문장으로 적어야 완료를 판정할 수 있습니다.'],
 ['포즈 좌표 상한 12','실게임은 관절 6개만 전송합니다. 실사용값에서 역산해 여유를 두었습니다.'],
 ['커스텀 맵은 1라운드','공식 맵처럼 3라운드를 강제하면 에디터에서 감당할 작업량이 과해집니다. 유저 부담을 기준으로 잘랐습니다.'],
 ['썸네일을 팔레트 그라디언트로','이미지 업로드를 받으면 저장소와 검수가 따라옵니다. 색 세 개만 고르게 해 스토리지 없이 카드가 구분되게 했습니다.']
],['st','q']))}

${blk('03','spec','명세 → 지시 → 구현',
`<p class="cap" style="margin-bottom:14px">같은 판단이 세 문서를 거쳐 화면이 되기까지의 대응입니다.</p>
<div class="tri">
  <div class="hd">명세 규칙</div><div class="hd">작업 지시</div><div class="hd">구현 결과</div>
  <div class="q">공개 전 제작자 본인이 한 번은 클리어해야 한다. 깰 수 없는 맵이 공개되면 다른 유저가 시간을 버린다.</div>
  <div>에디터에 검증 상태를 상시 노출하고, 미검증 상태에서는 공개 저장을 막되 비공개 저장은 허용할 것</div>
  <div>에디터 상단 <b>클리어 미검증</b> 배지와 안내 "공개 업로드하려면 테스트 플레이를 성공해야 합니다"</div>
  <div class="q">지형이 바뀌면 검증을 무효화한다. 포즈 변경은 무효화하지 않는다.</div>
  <div>지형 편집 이벤트에만 무효화를 연결할 것</div>
  <div>구현 중 <b>드래그 이동 경로에서 무효화가 누락</b>된 것을 발견해 보완</div>
  <div class="q">상한은 서버가 최종 검증한다. UI 검증은 편의 기능이다.</div>
  <div>한도 게이지를 실시간 표시하되, 서버 응답의 사유를 그대로 보여줄 것</div>
  <div>사이드바 <b>폴리곤 3/8 · 기믹 0/5 · 플레이어 4/4</b> 게이지와 저장 전 유효성 검사</div>
  <div class="q">에디터를 복제해 유저용을 만든다.</div>
  <div>관리자 에디터를 복사한 뒤 API 경로와 권한을 교체할 것</div>
  <div><b>지시와 다르게 구현.</b> 복제하면 버그 수정을 두 곳에 해야 하므로 한 컴포넌트에 분기 속성을 두는 방식으로 바꿨습니다</div>
  <div class="q">평점이 없을 때 0.0으로 표기하지 않는다.</div>
  <div>미집계 상태는 대시로 표시할 것</div>
  <div>0.0은 최저 평점으로 읽히므로 미집계와 구분. Phase 2 영역은 자리만 비워 두고 비활성 처리</div>
</div>
<div class="gal" style="margin-top:20px;grid-template-columns:1fr">
<figure><img src="${IMG}ws-editor.jpg" alt="맵 에디터 화면" loading="lazy" style="aspect-ratio:16/9">
<figcaption>맵 에디터 — 좌상단 <b>클리어 미검증</b> 배지, 우측 사이드바의 한도 게이지와 유효성 검사, 공개 업로드 조건 안내가 한 화면에 모여 있습니다</figcaption></figure>
</div>`)}

${blk('04','result','실사용 검증',
`<div class="metrics">
  <div class="metric"><div class="val">8P · 1G</div><div class="lb">상한을 채운 맵</div><div class="src">폴리곤 8개 = 설정한 상한값</div></div>
  <div class="metric"><div class="val">4건</div><div class="lb">공개된 유저 맵</div><div class="src">본인 2건 · 팀원 2건</div></div>
  <div class="metric"><div class="val">4–7회</div><div class="lb">맵당 플레이 횟수</div><div class="src">2026.08.13 기준</div></div>
</div>
<p style="margin-top:22px;color:var(--ink-2)">공식 맵 실측에서 상한을 8로 올려 잡았는데, 실제로 8개를 꽉 채운 맵이 만들어져 공개되었습니다. 다만 공개된 맵은 본인과 팀원이 만든 것이라 <mark>외부 사용자가 상한까지 썼다고 말할 수는 없습니다</mark>. 에디터에서 상한까지 쓰는 데 문제가 없다는 것까지 확인한 단계입니다.</p>
<p style="color:var(--ink-2)">가장 크게 남은 것은 무효화 조건의 누락을 스스로 발견한 일입니다. 명세를 쓸 때는 지형 편집만 생각했는데, 구현하면서 드래그로 옮기는 경로가 빠져 있다는 걸 알았습니다. 문서는 한 번 쓰고 끝나는 것이 아니라 구현이 되돌려주는 정보로 고쳐 쓰는 것이라는 걸 이 지점에서 확인했습니다.</p>`)}
<div class="artifacts"><a class="abtn" href="#/works/bodybuilder">${ico('work',16)}BodyBuilder로 돌아가기</a></div>`}

/* ===== ABOUT (전부 최신순) ===== */
const AWARDS=[
 ['2026.10','SSAFY 15기 특화 프로젝트','SSketch — 4인 멀티플레이 파티 게임','우수상 (반 3등)','기획 · PM · AI 도구 활용 구현','삼성 청년 SW·AI 아카데미'],
 ['2024.12','교내 학생 예비창업자 모의 IR DAY','플로라봇 — AI 반려 식물로봇','금상','발표자료 제작 · 사업 방향 보조','국립금오공과대학교 LINC 3.0 사업단'],
 ['2024.05','제15회 중소기업 바로알리기 IDEA 공모전','에세이 「내 길을 찾는 과정」','입선','단독 집필','중소기업중앙회'],
 ['2023.11','K7U-Belt 창업경진대회','SICK KICK — 소아청소년 케어 플랫폼','장려상','사업 방향·전략 전담 · 발표','국립한밭대학교'],
 ['2023.11','제4회 대한민국 신직업·미래직업 아이디어 공모전','콘텐츠 운영 컨설턴트 — 창직 아이디어','장려상','팀장 · 아이디어 제안 · 자료 조사','한국고용정보원'],
 ['2023.11','교내 창업동아리 시제품 제작 경진대회','솔라셀 킥보드 거치시설','창의 아이디어상','팀장 · 총무','국립금오공과대학교 창업원'],
 ['2023.06','교내 창업·발명 아이디어 경진대회','SICK KICK — 소아청소년 케어 플랫폼','대상','팀장 · 사업성 분석 전담','국립금오공과대학교 창업원'],
 ['2019.11','교내 창업·발명 아이디어 경진대회','다리 각도 조절 방석','은상','아이디어 구체화 · 사업성 분석','금오공과대학교 창업원'],
 ['2019.08','제18회 대한민국 청소년 발명 아이디어 경진대회','경추 교정 차량용 수면 베개','동상','구상 · 구현 · 자료 조사 전담','한국지식재산보호원']
];
const CERTS=[
 ['컴퓨터활용능력 2급','국가기술자격','대한상공회의소','2025.05'],
 ['데이터분석 준전문가 (ADsP)','국가공인 민간자격','한국데이터산업진흥원','2023.09'],
 ['FAT 1급','국가공인 민간자격','한국공인회계사회','2023.07'],
 ['정보처리기능사','국가기술자격','한국산업인력공단','2019.12']
];

const ABOUT_TABS=[
  {id:'skill',t:'역량'},{id:'edu',t:'학력 · 경력'},{id:'award',t:'수상 · 자격'},{id:'etc',t:'그 외 활동'}
];
function aboutTabs(cur){return `<div class="filters subtabs">${ABOUT_TABS.map(t=>
  `<a class="chip" href="#/about${t.id==='skill'?'':'/'+t.id}"${cur===t.id?' aria-current="page"':''}>${t.t}</a>`).join('')}</div>`}

function aboutProfile(){return `<section>
  <div class="profile">
    <img src="${IMG}profile.jpg" alt="김시후 프로필 사진">
    <div>
      <span class="eyebrow">About</span>
      <h1 class="d2" style="margin:10px 0 16px">김시후 · Kim Si Hoo</h1>
      <p class="body-l">게임·서비스의 규칙과 정책을 설계하고, 구현과 검증까지 연결합니다.</p>
      <p style="margin-top:14px;color:var(--ink-2)">경영학과 제조업 품질보증에서 배운 기준을 바탕으로, 요구사항을 정리하고 플레이에서 발견한 문제의 원인을 찾습니다.</p>
    </div>
  </div>
</section>`}
function aboutSkill(){return `<section class="sec">
  ${sechead('idea','역량','Competency')}
  ${[['game','게임 기획','규칙과 세계관을 함께 설계합니다. 표준을 쓸 곳과 직접 정할 곳을 나눕니다.',
     ['시스템·규칙 설계','밸런스 수치 설계','세계관·설정 구조화','UGC 품질 정책','레벨·콘텐츠 기획','플레이 흐름 설계']],
    ['service','서비스 기획','사용자의 행동을 먼저 정의하고, 예외까지 문서로 남깁니다.',
     ['요구사항 정의·명세 작성','화면 설계 · IA','진단·추천 로직 설계','예외 정책 정의','작업지시서 작성','범위 산정과 단계 분리']],
    ['biz','사업 기획','규제와 시장을 먼저 확인하고 그 결과를 설계에 반영합니다.',
     ['시장·경쟁사 분석','내외부환경 분석(PEST · VRIO 프레임워크)','수익 구조 설계','IR 자료 작성 및 발표','제도·인센티브 설계']],
    ['search','게임 분석 · QA','느낌을 재현 조건과 근거로 바꾸고, 다시 확인할 수 있게 남깁니다.',
     ['플레이 피드백 분류·우선순위','재현 조건 정의','회귀 테스트 설계','레퍼런스 게임 분석','이용자 관찰','버그 제보 양식 설계']]
  ].map(([k,t,l,items])=>`<div class="capgroup">
    <div class="hd">${ico(CAT[k]?CAT[k].i:k,18)}<h4>${t}</h4></div>
    <div class="lead">${l}</div>
    <ul>${items.map(x=>`<li>${x}</li>`).join('')}</ul></div>`).join('')}

  <div class="sub">${ico('tool',16)}도구</div>
  ${tbl([['도구','180px'],['수준','70px'],['활용 범위','']],[
    ['PowerPoint','고급','공모전 발표자료와 IR 자료 제작. 도식·다이어그램 작성 포함'],
    ['Word · Excel · 한글','중급','기획 문서 작성, 데이터 정리, 수식을 활용한 집계'],
    ['Notion · Discord · SharePoint','중급','온라인 협업과 일정 관리, 문서 버전 관리'],
    ['ChatGPT(Codex) · Claude(ClaudeCode) · Gemini(Antigravity)','중급','기획 프로토타입 및 구현으로 사용, 문서 작성과 코드 리뷰 보조'],
    ['Figma','초급','와이어프레임 확인과 화면 설계 커뮤니케이션'],
    ['Photoshop · Illustrator','초급','아이디어 시각화와 발표자료용 그래픽 편집'],
    ['SPSS','기초','설문 데이터 기초 통계 분석']
  ],['st','m','q'])}

  <div class="sub">${ico('code',16)}기술 이해도</div>
  ${/* 프론트·백엔드 같은 '영역'이 아니라 언어·기술 기준으로 묶습니다. 같은 언어의 라이브러리는 한 줄에 둡니다 */''}
  ${tbl([['기술','190px'],['수준','70px'],['내용','']],[
    ['JavaScript · TypeScript<br><span class="cap">React · Vue.js · Node.js</span>','중급','React·Vue.js로 컴포넌트 구조, 상태 관리, 비동기 통신을 다루며 서비스 화면 구현 (BodyBuilder · ProjectRG). Node.js 기반 웹 대전 게임 구현 (NeonTetrisWars). 구현 일부는 AI 코딩 도구 활용'],
    ['Python<br><span class="cap">pandas · numpy · Matplotlib</span>','중급','기본 문법과 2차원 배열 제어 로직 작성, DFS·BFS·완전탐색·Greedy 등 탐색 알고리즘의 기본 이해. pandas·numpy로 기초 분석 후 Matplotlib으로 시각화, 회귀분석과 통계적 방법론 학습'],
    ['Django<br><span class="cap">Python 웹 프레임워크</span>','기초','MTV 구조 이해와 RESTful API 설계 실습'],
    ['Unity<br><span class="cap">Unity 6 · URP</span>','기초','SSketch에서 AI 코딩 도구로 설정 창·방 화면·그림 도구 UI 구현, 에디터에서는 보이지 않던 빌드 전용 결함의 원인 추적'],
    ['머신러닝<br><span class="cap">Python</span>','기초','데이터 전처리와 회귀 분석 학습. 이미지 기반 질의응답(VQA) 모델 개발 프로세스를 데이터 가공부터 추론까지 경험']
  ],['st','m','q'])}
</section>`}
function aboutEdu(){return `<section class="sec">
  ${sechead('edu','교육사항','Education')}
  <div class="sub">${ico('edu',16)}학력</div>
  ${tbl([['기간','140px'],['학교','']],[
    ['2018.03 – 2025.08','<span class="st">국립금오공과대학교 경영학과</span> <span style="color:var(--ink-2)">학사</span><br><span class="cap">2023.09 – 2025.02 · 마케팅컨설팅연구실 학부연구생</span>']
  ],['m',''])}
  <div class="sub">${ico('idea',16)}연구 활동 (학부 연구생)</div>
  ${tbl([['기간','140px'],['구분','110px'],['내용','']],[
    ['2024.07 – 2024.12','논문','「기술수용모델의 용이성과 유용성이 생성형 AI 지속적 사용의도에 미치는 영향」제2저자<br><span class="cap">Lecture Notes in Computer Science 특별호 게재</span><br><span class="cap">DOI 번호 : 10.1007/978-3-031-75599-6_7</span>'],
    ['2024','창업 참여','AI·센서 기반 감성 교감 반려 식물로봇 「플로라봇」 / 아이디어 기획 및 구현, 사업 기획 보조<br><span class="cap">모의 IR 경진대회 금상 / 경북구미강소특구 우수창업자 기술사업화 지원사업 선정</span>']
  ],['m','st','q'])}
  <div class="sub">${ico('doc',16)}교육 이수</div>
  ${tbl([['기간','140px'],['과정','230px'],['내용','']],[
    ['2026.01 – 2026.12','삼성 청년 SW·AI 아카데미<br><span class="cap">삼성전자 · 멀티캠퍼스 · 대한상공회의소</span>','Python 문법과 알고리즘 학습, AI 데이터 분석·모델링 실습, Django·Vue.js 기반 풀스택 웹 개발'],
    ['2023.06 – 2023.10','Python 기반 사무행정 시티즌 빅데이터 사이언티스트(CBDS) 양성 과정<br><span class="cap">금오공과대학교 부설 평생교육원</span>','Python 데이터 수집·분석 훈련 및 시각화 실습, 회계 프로그램 실무. 과정 수료로 ADsP·FAT 1급 취득']
  ],['m','','q'])}
</section>
<section class="sec">
  ${sechead('work','경력','Experience')}
  ${tbl([['기간','140px'],['소속','170px'],['담당 업무','']],[
    ['2020.06 – 2022.07','수입검사(IQC) 담당<br><span class="cap">제조업 품질보증부 · 산업기능요원 소집해제</span>',
     '<b>수입검사(IQC) 업무 수행</b><br>· 수입 제품 입고 시 품목별 검사 기준서를 바탕으로 샘플링 검사와 전수 검사 시행<br>· 불량 제품 판정 후 대책서 및 개선 대책 요구<br>· 검사 결과 보고서 작성 보조']
  ],['m','','q'])}
</section>`}
function aboutAward(){return `<section class="sec">${sechead('trophy','수상',`${AWARDS.length}건 · Awards`)}<div class="award-list">${AWARDS.map(a=>`<article class="award-row"><div class="award-icon">${ico('trophy',24)}</div><time>${a[0]}</time><div><h3>${a[3]} · ${a[1]}</h3><p>${a[2]}</p><p>담당: ${a[4]}</p><small>${a[5]}</small></div></article>`).join('')}</div><p class="cap" style="margin-top:18px">증빙 자료는 요청 시 제공합니다.</p></section><section class="sec">${sechead('cert','자격','Certificates')}${tbl([['자격명','250px'],['종류','150px'],['시행 기관','180px'],['취득','']],CERTS,['st','q','q','m'])}</section>`}
function aboutEtc(){return `<section class="sec">
  ${sechead('etc','그 외 활동','Other')}
  ${tbl([['연도','118px'],['구분','108px'],['내용','']],[
    ['2024.09 –','기업 컨설팅','산학협력 기술지원 패키지 지원사업 참여 — 연구실 소속으로 경영 컨설팅 지도 참여'],
    ['2024','연구 용역','구미시 「청년근로자 코리빙 하우스 구축 기본계획 수립」 참여 — 데이터 정리 및 과제 코딩'],
    ['2019','특허 출원','3D 푸드 프린터의 분말·액상용 스크루 익스트루더<br><span class="cap">출원번호 10-2019-0017015</span>'],
    ['2019','게임 프로젝트','보드모아 — AR 기술 기반 보드게임 플랫폼, 팀장 및 가치 분석 <span class="cap">(자료 미보유)</span>'],
    ['2018.03 – 2025.02','동아리','교내 발명동아리 회원, 창업동아리 팀원 및 팀장']
  ],['m','st','q'])}
</section>`}

/* ===== HOBBY =====
   화면에 나오는 숫자와 그래프는 data.js 의 GAMES 목록에서 계산합니다.
   목록을 고치면 여기 숫자도 같이 바뀌므로 따로 손댈 곳이 없습니다. */
const HOBBY_TABS=[{id:'overview',t:'개요'},{id:'record',t:'플레이 기록'},{id:'docs',t:'문서'}];
function hobbyTabs(cur){return `<div class="filters subtabs">${HOBBY_TABS.map(t=>
  `<a class="chip" href="#/hobby/game${t.id==='overview'?'':'/'+t.id}"${cur===t.id?' aria-current="page"':''}>${t.t}</a>`).join('')}</div>`}
const rColor=k=>(GAME_REASONS.find(r=>r.k===k)||{c:'#C0CCD8'}).c;
const gCount=f=>GAMES.filter(f).length;
const rPct=k=>Math.round(gCount(g=>g[3]===k)/GAMES.length*100);

/* Hobby 첫 화면 — 영역 카드를 누르면 그 영역으로 들어갑니다 */
function hobbyHome(){return `<section class="hobbyhero"><span class="eyebrow">PLAY & OBSERVATIONS</span><h1 class="d1">좋아서 오래 한 것들,<br>그 안에서 발견한 것들.</h1><p>${GAMES.length}개 게임의 플레이 기록과 6년간의 길드 운영. 취미로 쌓아온 경험을 기록과 문서로 남겼습니다.</p></section><div class="hobbyareas"><a class="areacard" href="#/hobby/game">${ico('game',26)}<h2 class="h3">플레이의 흐름</h2><p>게임을 고르는 이유가 어떻게 바뀌었는지.</p><span class="go">경험의 흐름 보기 →</span></a><a class="areacard" href="#/hobby/game/record">${ico('content',26)}<h2 class="h3">${GAMES.length}개 게임 기록</h2><p>시기와 플레이 이유로 살펴보는 게임 목록.</p><span class="go">전체 기록 보기 →</span></a><a class="areacard" href="#/hobby/game/docs">${ico('doc',26)}<h2 class="h3">운영·분석 문서</h2><p>길드 운영과 라이브 서비스 관찰을 담은 두 문서.</p><span class="go">문서 읽기 →</span></a></div>`}

function gameHero(){return `<a class="crumb" href="#/hobby">${ico('game',15)} Hobby</a>
  <section class="hobbyhero">
    <span class="eyebrow">HOBBY · GAME</span>
    <h1 class="d1">오래 해 본 사람의 눈으로 게임을 봅니다</h1>
    <p>유년기부터 ${GAMES.length}개를 플레이했고, 무엇을 왜 했는지 기록해 두었습니다.
       그중 한 게임에서는 6년 동안 길드를 운영하며 규칙을 만들고 사람을 모았습니다.</p>
    <span class="deco">${ico('game',128)}</span>
  </section>`}

function hobbyOverview(){
  const rank=GAME_REASONS.map(r=>({k:r.k,n:gCount(g=>g[3]===r.k)})).sort((a,b)=>b.n-a.n);
  const cards=[
    {n:`${GAMES.length}개`,k:'기록한 게임',s:'유년기부터 26년간'},
    {n:`${gCount(g=>g[2]==='대학')}개`,k:'대학 이후 플레이',s:'플랫폼과 장르가 가장 넓어진 시기'},
    {n:`${rPct(rank[0].k)}%`,k:`가장 큰 이유는 ${rank[0].k}`,s:`${rank[1].k} ${rPct(rank[1].k)}%로 그다음`},
    {n:'6년',k:'한 게임에서 길드 운영',s:'2020 – 2026 · 서비스 종료까지'}
  ];
  /* 고르는 이유가 바뀌어 온 흐름 — 카드 모양을 통계 카드와 맞춥니다 */
  const flow=[
    ['유년','호기심','집에 있던 PC에서 우연히 게임을 발견했습니다.'],
    ['초등','성취감','키우는 캐릭터가 자라는 것을 보며 오래 붙잡았고, 간단한 게임을 만들어 보기도 했습니다.'],
    ['중등','사람','사람의 심리에 관심이 생기면서 몰입형 스토리를 찾기 시작했습니다.'],
    ['고등','서브컬처','리듬게임으로 서브컬처를 접했고, 창작자의 처우를 보며 콘텐츠 산업을 생각하게 됐습니다.'],
    ['대학','오래가는 것','사업의 생존을 공부하면서, 라이브 서비스 게임이 어떻게 버티는지를 보게 됐습니다.']
  ];
  return `<div class="statcards">${cards.map(c=>`<div class="statcard">
    <div class="k">${c.k}</div><div class="n">${c.n}</div><div class="s">${c.s}</div></div>`).join('')}</div>
  <div class="sub" style="margin-top:34px">${ico('idea',16)}게임을 고르는 이유가 바뀌어 온 흐름</div>
  <div class="flow">${flow.map(([s,tag,t],i)=>`<div class="flowstep">
    <span class="eyebrow">${String(i+1).padStart(2,'0')} · ${s}</span>
    <b>#${tag}</b><p>${t}</p></div>`).join('')}</div>
  <p class="cap" style="margin-top:20px">길드 운영 사례와 게임 분석 문서는 <a href="#/hobby/game/docs">문서</a>에 정리해 두었습니다.</p>`;
}

/* 시기별 막대와 이유 도넛 — 둘 다 GAMES 를 세어서 그립니다 */
function stageChart(){
  const max=Math.max(...GAME_STAGES.map(s=>gCount(g=>g[2]===s)));
  return GAME_STAGES.map(s=>{
    const n=gCount(g=>g[2]===s);
    const segs=GAME_REASONS.map(r=>({c:r.c,k:r.k,n:gCount(g=>g[2]===s&&g[3]===r.k)})).filter(x=>x.n);
    return `<div class="stackrow"><span>${s}</span>
      <span class="bar" style="width:${Math.round(n/max*100)}%">${segs.map(x=>
        `<i style="flex:${x.n};background:${x.c}" title="${s} · ${x.k} ${x.n}개"></i>`).join('')}</span>
      <span class="num">${n}개</span></div>`;
  }).join('');
}
function reasonDonut(){
  const parts=GAME_REASONS.map(r=>({...r,n:gCount(g=>g[3]===r.k)})).filter(p=>p.n);
  let at=0;const stops=parts.map(p=>{const from=at;at+=p.n/GAMES.length*100;
    return `${p.c} ${from.toFixed(1)}% ${at.toFixed(1)}%`}).join(',');
  return `<div class="donutwrap"><div class="donut" role="img"
      aria-label="플레이 이유 비율 — ${parts.map(p=>`${p.k} ${p.n}개`).join(', ')}"
      style="background:conic-gradient(${stops})"></div></div>
    <div class="legend">${parts.map(p=>`<span><i style="background:${p.c}"></i>${p.k}<b>${p.n}개 · ${Math.round(p.n/GAMES.length*100)}%</b></span>`).join('')}</div>`;
}
const GAME_FILTERS=[{v:'',t:'전체'}].concat(GAME_REASONS.map(r=>({v:r.k,t:r.k})));
function gameList(){
  const f=state.gfilter||'';
  const list=f?GAMES.filter(g=>g[3]===f):GAMES;
  return `<div class="filters" style="margin:18px 0 22px">${GAME_FILTERS.map(x=>
    `<button type="button" class="chip" aria-pressed="${f===x.v}" data-gf="${x.v}">${
      x.v?`<i style="background:${rColor(x.v)}"></i>`:''}${x.t}
      <span class="n">${x.v?gCount(g=>g[3]===x.v):GAMES.length}</span></button>`).join('')}</div>
  ${GAME_STAGES.map(s=>{
    const rows=list.filter(g=>g[2]===s);
    if(!rows.length)return '';
    return `<div class="gamegroup"><div class="gh"><h3>${s}</h3><span class="cap">${rows.length}개</span></div>
      <div class="gametags">${rows.map(g=>`<span class="gametag">
        <i style="background:${rColor(g[3])}"></i>${g[0]}<em>${g[1]}</em></span>`).join('')}</div></div>`;
  }).join('')||'<p class="cap">선택한 조건에 맞는 게임이 없습니다.</p>'}
  <p class="cap" style="margin-top:20px">점 색은 그 게임을 한 이유를 뜻합니다.</p>`;
}
function hobbyRecord(){return `<div class="chartgrid">
    <div class="chartcard"><h3>시기별 플레이한 게임</h3>
      <p class="lead">막대 안의 색은 그 시기에 게임을 고른 이유입니다.</p>${stageChart()}</div>
    <div class="chartcard"><h3>플레이 이유 비율</h3>
      <p class="lead">${GAMES.length}개 전체 기준입니다.</p>${reasonDonut()}</div>
  </div>
  <div class="sub" style="margin-top:30px">${ico('game',16)}게임 목록</div>
  ${gameList()}`}
/* 문서 목록 — href 가 있으면 사이트 안에서 바로 펼쳐 봅니다. 파일은 assets/docs/ 에 둡니다 */
const HOBBY_DOCS=[
  {id:'guild',i:'spec',t:'길드 운영 사례 정리',m:'PDF · 8쪽',href:'assets/docs/guild-ops-case.pdf',
   d:'카운터사이드 길드 「Time」을 2020년부터 서비스 종료까지 운영한 기록입니다. 규칙을 그렇게 정한 이유, 다른 길드와의 합병 협의, 미접 처리와 인원 이탈 대응을 사건별로 정리했습니다. 공지한 규칙 원문과 모집 글, 합병 협의 기록을 함께 실었습니다.'},
  {id:'analysis',i:'doc',t:'게임 분석 문서',m:'PDF · 6쪽',href:'assets/docs/game-analysis.pdf',
   d:'한 게임이 5년 넘게 서비스된 이유를 PEST와 소비자행동 이론으로 정리했습니다. 운영 이슈로 나빠진 여론이 사과문과 소통으로 돌아선 과정을 운영 관점에서 함께 다룹니다.'},
  {i:'content',t:'플레이 기록 원본',m:'요청 시 제공',
   d:'게임 목록을 플랫폼·첫 플레이 시기·플레이 이유로 정리한 표입니다. 이 화면의 그래프가 이 표에서 나옵니다.'}
];
function docViewer(d){return `<a class="crumb" href="#/hobby/game/docs">${ico('doc',15)} 문서</a>
  <div class="sechead">${ico(d.i,20)}<h2 class="d2">${d.t}</h2>
    <a class="cap" href="${d.href}" target="_blank" rel="noopener">새 탭에서 열기 ↗</a></div>
  <iframe class="pdfview" src="${d.href}#view=FitH" title="${d.t}" loading="lazy"></iframe>
  <p class="cap" style="margin-top:10px">문서가 보이지 않으면 위의 ‘새 탭에서 열기’를 눌러 주세요. ${d.m}</p>`}
function hobbyDocs(){
  const cur=HOBBY_DOCS.find(d=>d.id&&d.id===state.hdoc&&d.href);
  if(cur)return docViewer(cur);
  return `<div class="doclist">${HOBBY_DOCS.map(d=>{
    const inner=`${ico(d.i,20)}<div><h3>${d.t}${d.href?' <span class="open">바로 보기 →</span>':''}</h3>
      <p class="cap" style="margin-bottom:6px">${d.d}</p><span class="eyebrow">${d.m}</span></div>`;
    return d.href?`<a class="docrow" href="#/hobby/game/docs/${d.id}">${inner}</a>`
                 :`<div class="docrow">${inner}</div>`;
  }).join('')}</div>`;
}
function viewHobby(){
  if(state.hsec!=='game')return hobbyHome();
  const tab=HOBBY_TABS.some(t=>t.id===state.htab)?state.htab:'overview';
  const panel=tab==='record'?hobbyRecord():tab==='docs'?hobbyDocs():hobbyOverview();
  return gameHero()+hobbyTabs(tab)+`<div id="hobby-panel">${panel}</div>
    <p class="cap" style="margin-top:26px">직무 경력이 아니라 취미로 한 활동입니다.</p>`;
}

function viewAbout(){
  const tab=ABOUT_TABS.some(t=>t.id===state.tab)?state.tab:'skill';
  const panel=tab==='edu'?aboutEdu():tab==='award'?aboutAward():tab==='etc'?aboutEtc():aboutSkill();
  return aboutProfile()+aboutTabs(tab)+`<div id="about-panel" tabindex="-1">${panel}</div>`;
}

/* ===== CONTACT / 404 ===== */
function viewContact(){return `<section>
  <span class="eyebrow">CONTACT</span><h1 class="contact-lead">함께 만들 이야기를<br>기다립니다.</h1>
  <p class="body-l">프로젝트와 경험에 대해 궁금한 점이 있다면 연락해 주세요.</p>
  <dl class="contact-list">
    <div><dt>이메일</dt><dd><a class="contact-email" href="mailto:kimshlife@naver.com">kimshlife@naver.com</a><button type="button" class="abtn" id="copymail" aria-live="polite">이메일 복사</button></dd></div>
    <div><dt>GitHub</dt><dd><a href="https://github.com/kimshlife" target="_blank" rel="noopener">github.com/kimshlife ↗</a></dd></div>
    <div><dt>이력서</dt><dd>${RESUME?`<a href="${RESUME}" target="_blank" rel="noopener">이력서 보기</a>`:'<a class="abtn" href="mailto:kimshlife@naver.com?subject=이력서%20요청">이력서 요청하기 ↗</a>'}</dd></div>
  </dl>
  <p class="cap" style="margin-top:16px">전화번호와 주소는 게시하지 않습니다. 이메일로 연락 주시면 회신드리겠습니다.</p>
</section>`}
function view404(){return `<section class="empty">
  <img src="assets/brand/mark-navy.svg" alt="" style="width:118px;margin:0 auto 24px;opacity:.28">
  <h1 class="d2" style="margin-bottom:10px">요청하신 문서를 찾을 수 없습니다.</h1>
  <p class="cap" style="margin-bottom:20px">주소가 바뀌었거나 삭제된 페이지입니다.</p>
  <a class="abtn" href="#/works">${ico('work',16)}Works로 이동</a></section>`}

/* ===== 렌더 ===== */
function render(){
  const s=$('stage'),n=$('notes');let h='',nt='';
  switch(state.view){
    case 'select':h=viewSelect();syncNav('home');break;
    case 'about':h=viewAbout();syncNav('about');break;
    case 'works':h=viewWorks();syncNav('works');break;
    case 'detail':h=viewDetail();syncNav('works');
      nt=(P[state.slug]?.notes||[]).map(x=>`<div class="note"><b>${x.t}</b>${x.b}</div>`).join('');break;
    case 'workshop':h=viewWorkshop();syncNav('works');
      nt=`<div class="note"><b>소속</b>BodyBuilder의 기능입니다. 별도 프로젝트가 아닙니다.</div>
          <div class="note"><b>REMARK 03</b>지시와 다르게 구현한 행이 한 건 포함되어 있습니다.</div>
          <div class="note"><b>REMARK 04</b>상한 8까지 실제로 쓰이는지는 본인과 팀원이 만든 맵으로 확인했습니다. 외부 사용자에 의한 검증은 아닙니다.</div>`;break;
    case 'hobby':h=viewHobby();syncNav('hobby');break;
    case 'contact':h=viewContact();syncNav('contact');break;
    default:h=view404();syncNav('');
  }
  s.innerHTML=h;n.innerHTML=nt;
  document.body.dataset.view=state.view;
  document.title=(state.view==='select'?'게임·서비스 기획 / 게임 분석·QA':s.querySelector('h1')?.textContent||'포트폴리오')+' — 김시후';
  const section=({select:'home',detail:'works',workshop:'works'})[state.view]||state.view;
  document.querySelectorAll('[data-section]').forEach(a=>{if(a.dataset.section===section)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});

  document.querySelector('.canvas').classList.toggle('has-notes',!!nt);
  document.body.classList.toggle('is-select',state.view==='select');
  s.querySelectorAll('.tri').forEach(grid=>{
    const cells=[...grid.children],labels=cells.slice(0,3).map(el=>el.textContent);
    grid.replaceChildren();
    for(let i=3;i<cells.length;i+=3){
      const row=document.createElement('div');row.className='tri-row';
      cells.slice(i,i+3).forEach((cell,j)=>{
        const label=document.createElement('strong');label.className='tri-label';label.textContent=labels[j];
        cell.prepend(label);row.append(cell);
      });grid.append(row);
    }
  });
  s.querySelectorAll('.gal img').forEach(img=>{
    if(img.closest('button'))return;
    const button=document.createElement('button');button.type='button';button.className='gallery-open';
    button.setAttribute('aria-label','이미지 확대: '+img.alt);img.replaceWith(button);button.append(img);
  });
  moveFocus(s);
}
/* 이 사이트는 주소만 바뀌고 페이지는 다시 불러오지 않습니다.
   포커스를 옮겨 주지 않으면 키보드·스크린리더 사용자는 화면이 바뀐 것을 알 수 없습니다. */
let firstRender=true;
function moveFocus(stage){
  if(firstRender){firstRender=false;return;}          // 첫 진입은 그대로 둔다
  const t=stage.querySelector('h1')||stage;
  t.setAttribute('tabindex','-1');
  t.focus({preventScroll:true});
}
let lightboxOpener=null;
function closeLightbox(){ $('lb').close(); }
$('lb').addEventListener('close',()=>{document.body.classList.remove('modal-open');lightboxOpener?.focus();});
document.addEventListener('click',async e=>{
  const anchor=e.target.closest('[data-scroll],.skip-link');
  if(anchor){e.preventDefault();const t=document.getElementById(anchor.dataset.scroll||'stage');if(t){t.setAttribute('tabindex','-1');t.focus({preventScroll:true});t.scrollIntoView({block:'start'});}return;}
  const gf=e.target.closest('[data-gf]');
  if(gf){state.gfilter=gf.dataset.gf;render();document.querySelector('[data-gf][aria-pressed="true"]')?.focus({preventScroll:true});return;}
  const c=e.target.closest('[data-cat]');
  if(c){selectCat(c.dataset.cat);return;}
  const yt=e.target.closest('[data-yt]');
  if(yt){yt.outerHTML=ytFrame(yt.dataset.yt);return;}
  const opener=e.target.closest('.gallery-open');
  if(opener){const im=opener.querySelector('img');lightboxOpener=opener;$('lbi').src=im.src;$('lbi').alt=im.alt;$('lb').showModal();document.body.classList.add('modal-open');return;}
  if(e.target.id==='lb'||e.target.id==='lbx'){closeLightbox();return;}
  const cm=e.target.closest('#copymail');
  if(cm){try{await navigator.clipboard.writeText('kimshlife@naver.com');cm.innerHTML='복사했습니다';}
    catch{cm.innerHTML='복사할 수 없습니다. 이메일 주소를 선택해 주세요.';}
    setTimeout(()=>{cm.textContent='이메일 복사'},2500);}
});
/* Works 분류 — 고른 뒤에도 초점을 고른 칩에 둡니다 */
function selectCat(v){
  state.cat=v;render();
  const on=document.querySelector('[role="radio"][aria-checked="true"]');if(on)on.focus();
}
document.addEventListener('keydown',e=>{
  const r=e.target.closest('[role="radio"]');if(!r)return;
  const keys={ArrowRight:1,ArrowDown:1,ArrowLeft:-1,ArrowUp:-1};
  if(!(e.key in keys)&&e.key!=='Home'&&e.key!=='End')return;
  e.preventDefault();
  const all=[...r.parentElement.querySelectorAll('[role="radio"]')],i=all.indexOf(r);
  const n=e.key==='Home'?0:e.key==='End'?all.length-1:(i+keys[e.key]+all.length)%all.length;
  selectCat(all[n].dataset.cat);
});
route();
